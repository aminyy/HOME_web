/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tw;

import java.io.File;
import oms3.annotations.*;
import static oms3.annotations.Role.*;
import oms3.control.Iteration;

/** Thornthwaite water balance model.
 *
 * @author Olaf David
 */
public class Thornthwaite extends Iteration {

    // Model parameter
    @Role(PARAMETER)
    @Range(min=30, max=60)
    @In public double latitude = 35.0;
    
    @Role(PARAMETER)
    @Range(min=190, max=230)
    @In public double smcap = 201.0;
    
    @Role(PARAMETER)
    @Range(min=0.4, max=0.6)
    @In public double runoffFactor = 0.5;

 //   @Out public double of;

    @Role(PARAMETER + INPUT)
    public @In File  climateFile;

    @Role(PARAMETER + OUTPUT)
    public @In File  outputFile;
    
    // components
    private Climate climate = new Climate();
    private Daylen daylen = new Daylen();
    private HamonET et = new HamonET();
    private Output out = new Output();
    private Runoff runoff = new Runoff();
    private Snow snow = new Snow();
    private SoilMoisture soil = new SoilMoisture();
    
    @Initialize
    public void init() {
        conditional(climate, "moreData");

        // Climate
        connect(climate, "temp", soil, et, snow);
        connect(climate, "precip", soil, snow);
        connect(climate, "time", daylen, et, out);

        // Daylen
        connect(daylen, "daylen", et, out);

        // Soil
        connect(soil, "surfaceRunoff", out, runoff);
        connect(soil, "soilMoistStor", out);
        connect(soil, "actET", out);

        // PET
        connect(et, "potET", soil, snow, out);

        // Snow
        connect(snow, "snowStorage", out);
        connect(snow, "snowMelt", runoff);

        // Runoff
        connect(runoff, "runoff", out);

        // Input mapping
        mapIn("latitude", daylen, "latitude");
        mapIn("smcap", soil, "soilMoistStorCap");
        mapIn("runoffFactor", runoff, "runoffFactor");
        mapIn("climateFile", climate, "climateInput");
        mapIn("outputFile", out, "outFile");
     //   mapOut("of", out, "of");

        initializeComponents();
    }

    @Override
    public String toString() {
        return "TW";
    }

}
